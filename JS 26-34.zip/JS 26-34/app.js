// Chapter 26-30

// 1. Write a program that takes a positive integer from user &
// display the following in your browser.
// a. number
// b. round off value of the number
// c. floor value of the number
// d. ceil value of the number

// var number = prompt("Enter number");
// var round = Math.round(number);
// var floor = Math.floor(number);
// var ceil = Math.ceil(number);
// document.write("Number:"+ " " + number + "<br>" + "<br>" + "Round of value: " + " " + round+ "<br>" + "<br>"+ "Floor value" + " " + floor+ "<br>"+"<br> "+ "Ceil value" + " " +ceil);


// 2. Write a program that takes a negative floating point
// number from user & display the following in your browser.
// a. number
// b. round off value of the number
// c. floor value of the number
// d. ceil value of the number

// var number = -prompt("Enter number");
// var round = Math.round(number);
// var floor = Math.floor(number);
// var ceil = Math.ceil(number);
// document.write("Number:"+ " " + number + "<br>" + "<br>" + "Round of value: " + " " + round+ "<br>" + "<br>"+ "Floor value" + " " + floor+ "<br>"+"<br> "+ "Ceil value" + " " +ceil);



// 3. Write a program that displays the absolute value of a
// number.

//  var number = prompt("Enter number");
//  document.write("The absolut value of"+ " " + number + " " + "is" + " " +Math.abs(number));


// 4. Write a program that simulates a dice using random()
// method of JS Math class. Display the value of dice in your
// browser.:

// var random = Math.random()*6;
// var round = Math.round(random);
// document.write("Random Dice Value is " + " " +round);


// 5. Write a program that simulates a coin toss using random()
// method of JS Math class. Display the value of coin in your
// browser

// var head = prompt("Enter heads Usear name ");
// var tail = prompt("Enter Tails Usear name ");

// var hUpper = head.slice(0,1).toUpperCase();
// var hLetter = head.slice(1);
// var headJoin = hUpper + hLetter;

// var tUpper = tail.slice(0,1).toUpperCase();
// var tLetter = tail.slice(1);
// var tailJoin = tUpper + tLetter;

// var number = Math.random()*2+1;
// var floor = Math.floor(number);
// if (floor === 1){
//     document.write(floor + "<br>"+ "Heads" + " "+ headJoin + " " + "win the coin toss");
// }
// else{
//     document.write(floor + "<br> " +"Tails" + " " + tailJoin + " " + "win the coin toss");
// }


// 6. Write a program that shows a random number between 1
// and 100 in your browser.

// var number = Math.random()*100;
// var round = Math.round(number);
// document.write("Random Number Between 1 and 100:" + " "+ round);


// 7. Write a program that asks the user about his weight. Parse
// the user input and display his weight in your browser.
// Possible user inputs can be:
// a. 50
// b. 50kgs
// c. 50.2kgs
// d. 50.2kilograms


// var usear = prompt("Enter your Weight");
// if(usear === Number, "kg" && "kgs" && "kilogram"){
// document.write("The Weight of Usear is " + " " + usear);
// }

//  else if(usear !== Number, "kg" && "kgs" && "kilogram"){
//           document.write("Sorry")
//  }


// 8. Write a program that stores a random secret number from
// 1 to 10 in a variable. Ask the user to input a number
// between 1 and 10. If the user input equals the secret
// number, congratulate the user.

// var usear = prompt("Enter number 1 to 10");
// var number = 5;
// var match = usear.match(number);
// if (match){
//     document.write("Congratulations you win");
// }
// else{
//     document.write("Sorry you Loss");
// }


// Chapter 31-34

// 1. Write a program that displays current date and time in
// your browser.

// var date = new Date();
// document.write(date);


// 2. Write a program that alerts the current month in words.
// For example December.

// var m = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "Octuber", "November", "December"];
// var date = new Date();
// var month = date.getMonth();
// var thisMonth = m[month];
// alert("Current Month is:" + " " + thisMonth);


// 3. Write a program that alerts the first 3 letters of the current
// day, for example if today is Sunday then alert will show
// Sun.

// var d = ["Sun", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
// var date = new Date();
// var day = date.getDay();
// var thisday = d[day];
// alert("Today is:" + " " + thisday);


// 4. Write a program that displays a message “It’s Fun day” if
// its Saturday or Sunday today.


// var d = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
// var date = new Date();
// var day = date.getDay();
// var thisday = d[day];
// if (thisday === "Saturday" && "Sunday"){
//     alert("It's Funday");
// }
// else if (thisday !== "Saturday" && "Sunday"){
// alert("Today is:" + " " + thisday);
// }


// 5. Write a program that shows the message “First fifteen
// days of the month” if the date is less than 16th of the month
// else shows “Last days of the month”.

// var month = new Date();
// var date = month.getDate();
// if (date < 16){
//     document.write("First fifteen days of the month")
// }
// else if(date > 16){
//     document.write("Last day of month")
// }



// 6. Write a program that determines the minutes since
// midnight, Jan. 1, 1970 and assigns it to a variable that
// hasn't been declared beforehand. Use any variable you like
// to represent the Date object.

// var date = new Date();
// var second = new Date(1970);
// var time = date.getTime();
// var m =  time/(1000*3600)
// document.write("Cureent Date:" + " " + date + "<br>" + "Elapsed milliseconds since January 1, 1970:" + " " + time + "<br>" + "Elapsed minutes since january 1, 1970:" + " " + m )



// 7. Write a program that tests whether it's before noon and
// alert “Its AM” else “its PM”.

// var date = new Date();
// var hour = date.getHours();
// if (hour > 12){
//     document.write("Its PM")
// }
// else {
//     document.write("Its AM");
// }


// 8. Write a program that creates a Date object for the last day
// of the last month of 2020 and assigns it to variable named
// // laterDate.

// var date = new Date("december 31, 2020");
// document.write("Later Date:" + " " + date);

// var date = new Date().getT;
// var time = date.getTime();
// var a=time -3600000
// var b = date.getHours();
// var c = date - b
// document.write(date)


// 9. Create a date object of the starting date of this Ramadan
// and alert the number of days past since 1st Ramadan?
// Note: 1st Ramadan was on June 18, 2015

//  var date = new Date("june 18, 2015");
 
//  var time = date.getTime();
//  var dat2=new Date().getTime()
//  var a =  dat2 -time 
//  var b = Math.round(a / (60*60*24*1000));
// console.log(b)



// 10. Write a program that displays in your browser the
// seconds that elapsed between the reference date and the
// beginning of 2015.

// var date = new Date("Jun 28 2021 23:38:19");
// var date2 = new Date();
// var second = date2.getSeconds();
// document.write(date + "<br>"+ second + " " +"Seconds had passed since biginning of 2021" )


// 11. Create a Date object for the current date and time.
// Extract the hours, reset the date object an hour ahead and
// finally display the date object in your browser.

//  var dt = new Date();
//          dt.setHours( dt.getHours() -1 );
//          document.write( dt );


// 12. Write a program that creates a date object and show the
// date in an alert box that is reset to 100 years back?

//  var date = new Date();
//          date.setFullYear( date.getFullYear() - 100 );
//          document.write( date );


// 13. Write a program to ask the user about his age. Calculate
// and show his birth year in your browser.

// var dob = new Date(prompt("Enter your date of bith","Jan 1, 1970"))
// var dobmili = dob.getTime();
// var today = new Date();
// var todaymili = today.getTime()
// var diff = todaymili - dobmili;
// var accuage = Math.floor(diff/(1000*60*60*24*30*12))
// document.write(accuage);



// 14. Write a program to generate your K-Electric bill in your
// browser. All the amounts should be rounded off to 2
// decimal places. Display the following fields:
// a. Customer Name
// b. Current Month
// c. Number of units
// d. Charges per unit
// e. Net Amount Payable (within Due Date)
// f. Late Payment Surcharge
// g. Gross Amount Payable (after Due Date)
// Where,

// document.write("<h1>k-Electric Bill</h1>" + "<br>");
// var Customer = prompt("Enter your name");
// var date = new Date();
// var month = date.getMonth();
// var numberOfUnits = 410;
// var chargesPerUnits = 16;
// var latePaymentCharges = 350;
// var netAmount = numberOfUnits * chargesPerUnits;
// var net_late = netAmount + latePaymentCharges;
// document.write("Customer Name:" + " " + Customer + "<br>" + "Month:" + " " + month + "<br>" + "Number of Units:" + " " + numberOfUnits + "<br>" + "Charges Per Units:" + " " + chargesPerUnits + "<br>" + "<br>" + "Net Amount Payable(Within Due Date):" + " " + netAmount + "<br>" + "Late Payment Surcharge:" + " " + latePaymentCharges + "<br>" + "Gross Amount Payable(after Due Date)" + " " + net_late );






